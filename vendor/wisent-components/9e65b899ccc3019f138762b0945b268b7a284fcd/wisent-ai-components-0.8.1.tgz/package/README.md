<p align="center">
  <img src="assets/readme-banner.svg" alt="Wisent Components — canonical Wisent design tokens and interface components" width="100%">
</p>

<!-- wisent-readme-signals:start -->
[![Source](https://img.shields.io/badge/GitHub-Source-181717?logo=github)](https://github.com/wisent-ai/wisent-components) [![Issues](https://img.shields.io/badge/GitHub-Issues-181717?logo=github)](https://github.com/wisent-ai/wisent-components/issues) [![Wisent](https://img.shields.io/badge/Wisent-Website-0B0B0B)](https://wisent.com) [![Discord](https://img.shields.io/badge/Discord-Join-5865F2?logo=discord&logoColor=white)](https://discord.gg/qRjpkthq54) [![LinkedIn](https://img.shields.io/badge/LinkedIn-Follow-0A66C2?logo=linkedin&logoColor=white)](https://www.linkedin.com/company/wisent-ai/) [![X](https://img.shields.io/badge/X-Follow-000000?logo=x&logoColor=white)](https://x.com/wisentai) [![Enterprise](https://img.shields.io/badge/Enterprise-Book%20a%20call-0B0B0B?logo=calendly)](https://calendly.com/lbartoszcze)
<!-- wisent-readme-signals:end -->

[![Source](https://img.shields.io/badge/GitHub-Private_source-181717?logo=github)](https://github.com/wisent-ai/wisent-components) [![Package](https://img.shields.io/badge/package-%40wisent--ai%2Fcomponents-273328)](package.json) [![Version](https://img.shields.io/badge/version-0.8.1-9ecca0)](package.json) [![React](https://img.shields.io/badge/React-18%E2%80%9319-61DAFB?logo=react&logoColor=111111)](package.json) [![Discord](https://img.shields.io/badge/Discord-Join-5865F2?logo=discord&logoColor=white)](https://discord.gg/qRjpkthq54) [![License](https://img.shields.io/badge/license-private-critical)](package.json)

# Wisent Components

`@wisent-ai/components` and the `WisentDesignSystem` Swift package are the runtime source of truth for shared Wisent design tokens and reusable interface components. Wisent applications consume them instead of copying brand colors, spacing, radii, typography, panels, badges, buttons, page headers, metrics, loading states, or accessibility behavior into each repository.

The repository also retains the versioned Figma source snapshots under `figma/`. Figma records design intent; `tokens.json` and the exported components are the implementation contract applications execute.

The shared documentation layout, app-shell contract, product-docs structure, and component release history are published from website source at [wisent.com/docs](https://wisent.com/docs).

## Use it

Web consumers require Node.js 20 or newer and React 18 or 19. Native consumers require Swift 6 and macOS 14 or iOS 17. The repository is private, so both package managers use the consuming environment's existing GitHub credentials.

```bash
npm install github:wisent-ai/wisent-components
```

Import the stylesheet once in the application's global stylesheet:

```css
@import "@wisent-ai/components/styles.css";
```

Then use the shared interface primitives without coupling UI to an application framework:

```jsx
import {
  GitHubLoginButton,
  GoogleLoginButton,
  WisentButton,
  WisentPageHeader,
  WisentPanel,
} from "@wisent-ai/components";

export function AccountPage({ loadingProvider, signIn }) {
  return (
    <>
      <WisentPageHeader
        eyebrow="Account"
        title="Connect to Wisent"
        description="One visual contract across Wisent applications."
      />
      <WisentPanel>
        <GoogleLoginButton
          loading={loadingProvider === "google"}
          onClick={() => signIn("google")}
        />
        <GitHubLoginButton
          loading={loadingProvider === "github"}
          onClick={() => signIn("github")}
        />
        <WisentButton>Continue</WisentButton>
      </WisentPanel>
    </>
  );
}
```

Native applications add the repository as a Swift package and import the product:

```swift
import SwiftUI
import WisentDesignSystem

struct Overview: View {
    var body: some View {
        WisentPanel {
            WisentPageHeader(
                eyebrow: "Operations",
                title: "Brama",
                detail: "Private model routing on this Mac.",
                symbol: "point.3.connected.trianglepath.dotted"
            )
        }
        .background { WisentCanvasBackground() }
    }
}
```

A successful integration renders branded, keyboard-focusable buttons and leaves provider authentication, redirects, and session state with the consuming application. Production consumers pin the dependency to an exact commit so every deployed interface remains attributable and rollback is a dependency-revision change.

## Contract

The package currently owns:

- the full brand, grayscale, semantic color, typography, spacing, radius, shadow, and motion token set reconciled from Wisent App, Wisent Landing, and Wisent iOS;
- reusable React buttons, panels, badges, page headers, metric cards, OAuth actions, provider icons, generic icon wrappers, skeleton loading states, and layout primitives;
- the Figma application families: brand marks, top bars, sidebar navigation, side menus, app shells, chats, project cards and showcases, capability-model presentations, empty states, modals, and status panels;
- the application shell at Wisent App's own values, under the names `WisentDesignSystem` already uses: `WisentAppLayout`, `WisentNavigation`, `WisentCreateAction`, `WisentContextBar`, `WisentScreen`, `WisentStatusChip`, `WisentQueueRow`, `WisentSignalStrip`, `WisentSectionBox`, `WisentAlertPanel`, `WisentMutationBar`, `WisentToast`, `WisentToastRegion`, and the `wisent-type-*` scale;
- reusable SwiftUI canvas, panel, page and section headers, metric cards, badges, empty states, skeleton loading states, typography, colors, and button styles;
- the complete landing-page runtime: header, hero, recognition, mechanism, proof, objection, decision, footer, and page assembly — each zone in every form it can take: the hero as a statement, a split with an artifact, or a headline over a transcript; recognition as cards or flat columns; mechanism as numbered steps or before/after pairs; proof as a transcript, a table, an attributed claim, or a screenshot with alt text;
- `landing-components.json`, which describes every landing component, its export, zone, forms, `defaultForm`, and the content contract of each form for the landing pipeline; a component plan names one form per zone, or an ordered list when the page carries a zone more than once, and `landingFormOf(componentPlan, id, ordinal)` returns the nth section's form;
- the product-documentation runtime: `DocumentationLayout` with its fixed section fields, its ordered rich `blocks` and its section `links`, the shell a product surface wears above and below the page — `WisentDocsHeader` and `WisentDocsFooter` — and `WisentDocsSearch` over the same pages;
- `figma-components.json`, which maps recurring structures in the three shared Figma files to their generic runtime implementation and states which data remains consumer-owned;
- bundled Hubot Sans, Hubot Sans Expanded, and IBM Plex Mono assets used by the shared components;
- loading, disabled, focus-visible, reduced-motion, Dynamic Type, dark appearance, and accessible-name behavior.

### Waiting is drawn as the content, never as a spinning circle

A rotating indicator says only that something is happening. A skeleton says
what is arriving and where it will sit, so the layout does not move when the
data lands. Nothing that reads content therefore spins:

- `WisentSkeleton` is one shape — `line`, `heading`, `block`, `circle` or
  `pill`. It is `aria-hidden` because it carries no information of its own.
- `WisentSkeletonText`, `WisentSkeletonList`, `WisentSkeletonTable` and
  `WisentSkeletonCard` compose those shapes into the four layouts applications
  actually wait on, and each one announces the wait once through
  `WisentSkeletonGroup` (`role="status"`, `aria-busy`, and a `label` that names
  what is being read rather than the word "Loading" alone).
- A control whose own action is in flight keeps its box, its icon and its
  accessible name; `WisentBusyLabel` shimmers the label in place. Nothing is
  replaced, so nothing reflows on settle. Keep the resting word as the child:
  swapping "Save" for "Saving…" drops the control's accessible name at the one
  moment a screen reader needs it. `busy` is required and throws when absent —
  ten applications aliased this onto a local name whose shimmer was
  unconditional, and a default of `false` would turn every one of those call
  sites into a silent no-op.
- `prefers-reduced-motion` and `accessibilityReduceMotion` drop the sweep and
  leave a flat placeholder.

`WisentDesignSystem` carries the same four composites plus `WisentSkeleton`,
and `WisentAction(_:symbol:kind:isEnabled:isBusy:perform:)` is the SwiftUI
counterpart of `WisentBusyLabel`: `isBusy` keeps the verb, the icon and the
accessible name and shimmers a bar where the word sits, while the button stops
accepting a second press. It exists because five applications wrote
`model.isRunning ? "Saving…" : "Save"` instead — the exact swap this section
forbids — and there was no seam in the shell's action bar to do better.

The one place a spinner survives is `WisentProgressPanel`, and only because it
is not a read: scanning a repository, sculpting a model, submitting a
credential request or answering a question has no unloaded content to
impersonate, so it reports its real title and status instead of pretending
records are about to land. Reaching for it while records are being read is the
mistake this section exists to prevent — that state has a shape, and the shape
is the skeleton.

**An application can adopt this without taking the component library.** The
rules ship on their own, and the four values worth changing per product are
named, so a dark application sets variables instead of forking the
implementation:

```css
@import "@wisent-ai/components/skeleton.css";

:root {
  --wisent-skeleton-base: rgb(255 255 255 / 10%);   /* resting fill */
  --wisent-skeleton-sweep: rgb(255 255 255 / 22%);  /* travelling highlight */
  --wisent-skeleton-surface: #16181a;               /* the card's panel */
  --wisent-skeleton-border: #2a2e31;                /* card edge, table header rule */
}
```

The last two are there because the first two were not enough: an application
that set only base and sweep still got a white card with a light border, and had
to override `--wisent-color-white` — a token that is not about skeletons — to
fix it. Four named variables, and nothing reaches past them.

**Put the import first, ahead of every other `@import`.** Next.js inlines a
stylesheet at the top only when it is the first statement in the file; a font
`@import url(...)` above it pushes these rules to the end of the emitted bundle,
after the Tailwind utilities, and `.wisent-skeleton--line { height: 0.75em }`
then quietly beats the `h-11` a call site asked for. Nothing errors — the
skeletons are simply the wrong size. Measured in one application at byte 56695
against `.h-4` at 12501, and fixed by moving one line. Verify it rather than
trusting the order you wrote: build, then compare the offset of
`.wisent-skeleton` with a utility class in the emitted CSS. Vite is unaffected.

```jsx
import { WisentSkeletonTable, WisentBusyLabel } from "@wisent-ai/components/skeleton";
```

SwiftUI says the same thing with one modifier, and for the same reason — the
view that knows it is dark is the container, not the bar:

```swift
import WisentDesignSystem

WisentSkeletonGroup(label: "Loading subscription plans") {
    WisentSkeleton(.block, height: 96)
}
.wisentSkeletonTone(.onDark)
```

`.automatic` is the default and draws the design-system ramp, which already
follows light and dark mode; `.onLight` and `.onDark` are for the surfaces the
tokens do not cover, such as a chat bubble, a paywall or an image overlay.

Every token `skeleton.css` reads carries a literal fallback, so it renders
correctly without the token `:root` block that `styles.css` supplies. Forking
these rules into an application is the one thing to avoid: `npm run build` fails
this package if a spinner returns to `src/skeleton.css` or `src/components.css`,
if any runtime export is named `*Spinner`, or if the skeleton contract goes
missing — and a forked copy sits outside that check.

It deliberately does not own authentication, routing, translations, product-specific copy, project names, model capabilities, glyph artwork, or product state. Those values enter generic components through props. A component enters this package only when at least two applications can consume the same API.

`tokens.json` is the runtime contract. Its `color` and `dark` groups are
written by `npm run tokens` from `figma/tokens.map.json`, which says which
Figma variable each token is (`brand` is `Colors/Brand/Green 500`, `danger`
is `Colors/Error/Red 600`), and `figma/vocabulary.json`, which carries the
designer's variable names and the values the exports resolve them to; see
[Colour tokens are Figma variables](#colour-tokens-are-figma-variables).
Its `font`, `type` and `weight` groups are written by the same command from
the library's 143 text styles (`figma/library.json`): `font` names the
three families the styles use with the fallback stack the map gives each
role, `type` is the scale the styles share — `display-2xl` (72/90,
-0.02em) … `display-xs` (24/32), `text-xl` (20/30) … `text-xs` (12/18) —
and `weight` the five weights they set (300 … 700); a family the map names
that no style uses, or a family whose styles disagree with the scale, stops
the command. The space, radius, shadow and motion groups are named by hand
and held to what the exporter measured: a space token must be a padding or
gap some visible auto-layout frame sets (`spacings`), a radius a corner
some layer draws (`cornerRadii`), a shadow one the design draws, written
as `x y blur spread rgba(r, g, b, a)` (`shadows`); `npm run tokens` refuses
one that is not. On 2026-09-14 `surface`, `raised` and `toast` were shadows
no file drew; now `surface` and `control` are the design's 0 1 2 at 5 %
(1,652 layers, the App card among them), `raised` its 0 20 24 −4 at 8 %,
`glass` its 0 12 15 black at 6 % (the glass buttons), `toast` its 0 8 12 at
4 %. Change the map or a hand group, run `npm run tokens` and `npm run
build`, and commit `tokens.json`, the generated `dist/` and the generated
`Sources/WisentDesignSystem/WisentDesignColors.swift` with the source
change; the build refuses a `tokens.json` that is not what `npm run tokens`
writes. Applications must not override component internals; supported
variation is exposed through component props and CSS custom properties.

The components are held to the Figma components they claim
(`figma-components.json`). `node src/cli.mjs figma-variables --components`
reads every non-icon component of the inventory by id — size, layout,
paddings, gap, corner, fills with their variables and gradient stops,
strokes, effects, and the text it sets, one level of children deep — into
`figma/files/<folder>/components.json`, through the file
`figma/sources.json` names for the export. On 2026-09-14 Wisent Web's 36
read whole; Wisent Web App's duplicate of January carries 12 of the 54
the February export names, and Wisent App's export is of a file that no
longer exists, so those wait for the originals' team. What Wisent Web
measured is now what the stylesheet draws: `WisentAction` is 38 px high
with 6 px above and below, 12 px before the label and 6 px after the
trailing icon, a 6 px gap, a 12 px corner and Hubot Sans Medium 14/20;
its `default` and `hero` variants are the design's glass — #d6d6d6 at
10 % (30 % for hero) under a white highlight, a #f2f2f2 → #818181 → white
stroke, an 18 px backdrop blur, the `glass` shadow, a Gray 950 or white
label, the trailing icon in a 26 px square with an 8 px corner and the
`control` shadow; `badge` is the same glass at 30 %, 32 or 28 px high;
`compact` is Badge App, 28 px square with an 8 px corner. `WisentTopBar` is
72 px high, 16 px around and 24 px before the brand, a 64 px gap, a 16 px
corner, white at 40 % with a Gray 300 stroke at 20 % and the inner
highlight the design draws; `WisentSideMenu` is 240 px wide with 8 px each
side and a 24 px gap. The `primary` and `quiet` variants claim no Figma
component and keep the brand fill and the bare label they had.

The stylesheet sets its text through the scale — `font-size:
var(--wisent-type-text-sm-size)` with
`line-height: var(--wisent-type-text-sm-line-height)` — and so does an
application that writes CSS. Until 2026-09-14 `components.css` set 9, 10,
11, 13, 15, 21, 22 and 26 px in sixty places, sizes no Figma file types;
the lint's `font-size` rule now reads the sizes the exporter measured on
visible text layers (`figma/vocabulary.json` `textSizes`) and refuses one
the design never types.

## Application shell

Wisent App drew the shell by hand and kept it: a 296 px sidebar, 36 px rows
4 px apart, sections 20 px apart, 16/24 Hubot Sans Medium in `#424846`, the
active row on `#f4f4f4` in `#4f6650`, a 20 px trailing icon, a 24 px avatar
with a 1.25 px border, the `+1` badge in `#769978` on `#ecf2f0`, and
`0 1px 2px rgba(10,13,18,0.05)` under the create control. Every one of those
numbers is `figma-navigation-exact-specs.txt` (Figma node 47:24441), and every
one of them is now a rule in `src/components.css` rather than a value pasted
into one repository's leaves. The names are the SwiftUI package's names, so
the two runtimes describe the same shell:

```jsx
const sections = [
  { items: [{ label: "Home", href: "/home", active: true, icon: <HomeGlyph /> },
            { label: "Community", href: "/community", icon: <CommunityGlyph /> }] },
  { title: "Recent", items: [{ label: "Nova", href: "/c/nova", avatar: <Face />, badge: "+1" }] },
];
<WisentAppLayout
  sidebar={<WisentNavigation label="Wisent App" sections={sections} link={Link}
    footer={<WisentCreateAction label="Create character" badge="New" href="/create" />} />}
  inspector={<CharacterDetail id={selected} />}>
  <WisentScreen title="Characters" eyebrow="workspace" detail="read 12:04:31" actions={<Deploy />}>
    <WisentSectionBox title="Needs a decision" actions={<ReviewAll />}>
      <WisentQueueRow title="nova-3" detail="char_01HX" trailing="2 d"
        status={<WisentStatusChip tone="warning">review</WisentStatusChip>} />
    </WisentSectionBox>
  </WisentScreen>
</WisentAppLayout>
```

`WisentScreen` draws its own `WisentContextBar`, so pass it as `children` and
leave `WisentAppLayout`'s `contextBar` slot alone; the slot is for a bar pinned
above content that is not a screen. The content column carries the `main`
landmark and the Swift `contentMaximumWidth` of 1 120 px. The other
measurements are the Swift `WisentAppLayout` constants — 320 px inspector,
44 px context bar, 1 000 × 700 px minimum window — and 1 000 px is also the
breakpoint: below it the columns stack rather than forcing a horizontal
scrollbar, so the navigation stays reachable.

Type comes from the `wisent-type-*` classes, which are the Swift
`WisentTypeScale` sizes, weights and faces and nothing else — no color, so
they compose: `wisent-type-screen-title`, `wisent-type-section`,
`wisent-type-panel-title`, `wisent-type-metric`, `wisent-type-body`,
`wisent-type-body-strong`, `wisent-type-caption`, `wisent-type-identifier`.

A failure is sized like a failure (`WisentAlertPanel`: full width, a severity
edge, the backend's own sentence left selectable) and a healthy signal is sized
like a healthy signal (`WisentSignalStrip`: one line in a divided strip).
Reversing the two is the defect the native baseline captures recorded, and it
is the reason both components exist instead of one tile grid.

### Toasts, with or without Sonner

`WisentToast` and `WisentToastRegion` are plain React with no toast dependency,
and they carry the rules Wisent App wrote into `src/app/globals.css:160-329`:
16 px radius, 16/16/28 padding, 12 px gap, the `toast` shadow, a 24 px icon
tile on `#f4f4f4`, a 36 px close control, and the 4 px progress bar inset to
the copy column. `progress` takes a fraction for a determinate bar, runs the
design's 7 s ease when omitted, and takes `false` for a toast that does not
dismiss itself.

An application that keeps Sonner does not restyle it again — it points Sonner
at these classes and deletes its own `!important` block:

```jsx
<Toaster
  toastOptions={{
    classNames: {
      toast: "wisent-toast",
      icon: "wisent-toast__icon",
      content: "wisent-toast__content",
      title: "wisent-toast__title",
      description: "wisent-toast__description",
      actionButton: "wisent-toast__action",
      closeButton: "wisent-toast__close",
    },
  }}
/>
```

Sonner positions its own viewport, so `WisentToastRegion` is unused in that
case; the `wisent-toast*` rules are written to hold their geometry from the
class alone, and the progress bar's 52 px inset is expressed as
`16px + 24px + 12px` — the padding, the icon tile and the gap — rather than as
a constant that drifts when one of the three changes.

## Product documentation, and the shell around it

`DocumentationLayout` is the one documentation look: a collapsible sidebar of
sections, a reading column with kicker, title, lede, sections, code blocks,
callouts and pagination. It is server-safe — no hooks, native
`<details>/<summary>` — and it takes the framework's link component through
`link`, defaulting to a plain anchor.

A section may be written as the fixed fields (`paragraphs`, `bullets`,
`steps`, `commands`, `table`, `callout`) or as `blocks`, an ordered list that
places a table between two paragraphs instead of after all of them:
`paragraph`, `heading`, `list`, `code`, `table`, `callout`. Text in a block
carries inline markup — `[label](href)`, `` `code` ``, `**bold**`,
`*emphasis*` — and the link goes through the same `link` renderer as the rest
of the layout. `links` is the section's way out: `{ href, label, description }`
rendered last. Blocks render before the fixed fields, so a page that uses only
the old shape renders exactly as it did.

`WisentDocsHeader` and `WisentDocsFooter` are the shell around that page and
around the product page it belongs to: the brand, a divider, the surface name,
and the nav `Capabilities`, `Workflow`, `Docs`, `Ecosystem`. A section link is
a fragment on the product page and absolute (`https://<slug>.wisent.com#…`)
from `/docs`; `hasDocs` adds the Docs link and `section="docs"` marks it
`aria-current="page"`; the ecosystem is `https://wisent.com/` for a named
surface and `/` for the ecosystem site itself. `surfaceSlug` defaults to the
lowercased surface name, and `Link` defaults to an anchor.

`WisentDocsShell` is the page around a body — the header, a `main` column on
the canvas, the footer — so a site composes only what goes between:

```jsx
import Link from "next/link";
import { DocumentationLayout, WisentDocsShell } from "@wisent-ai/components";
import { WisentDocsSearch } from "@wisent-ai/components/docs-search";

export default function DocsPage({ page, nav, pages }) {
  return (
    <WisentDocsShell surfaceName="Probierz" section="docs" hasDocs Link={Link}>
      <WisentDocsSearch surface="probierz" pages={pages} />
      <DocumentationLayout product="Probierz" page={page} nav={nav} link={Link} />
    </WisentDocsShell>
  );
}
```

`WisentDocsHeader` and `WisentDocsFooter` remain exported for a page that
needs one without the other.

This shell arrived here from seven generated landing sites — `echo-landing`,
`las-landing`, `lem-landing`, `most-landing`, `probierz-landing`,
`skarbiec-landing`, `skrzynka-landing` — which each carried a byte-identical
`src/components/docs-chrome.jsx` with a hard-coded stone palette, eleven
per-product accent hexes, a blurred accent glow, a grid backdrop and a radial
vignette, plus a forked copy of this layout: skrzynka had added the rich
blocks, probierz the section links. Both forks are folded in above; the copies
are retired, and with them the accent, the glow and the backdrop. Class names
are `wisent-docs-header`, `wisent-docs-header__inner`, `wisent-docs-brand`,
`wisent-docs-brand__divider`, `wisent-docs-brand__surface`,
`wisent-docs-shell-nav`, `wisent-docs-shell-nav__link`, `wisent-docs-footer`,
`wisent-docs-footer__inner`, `wisent-docs-footer__note`, `wisent-docs-shell`, `wisent-docs-shell__main`. The shell is flat
`--wisent-color-background` between `--wisent-color-border` rules, and it is
dark when the OS or the document says so, never because a site forked it.

`WisentDocsSearch` searches one surface's documentation and is the package's
only client component, so it has its own entry point and the layout above
stays server-only:

```jsx
// A server page may import and render it; the "use client" boundary is inside
// the module, so nothing else in the page becomes a client component.
import { WisentDocsSearch } from "@wisent-ai/components/docs-search";

<WisentDocsSearch surface="skrzynka" pages={allPages} Link={Link} />
```

It takes the same `pages` array the layout renders — no index to build, no
service to call — reads a section's `blocks` as well as its fixed fields, and
lists up to twelve hits addressed at the published surface
(`https://<surface>.wisent.com/docs[/slug][#heading]`, the heading anchored
exactly as the layout anchors it). Classes: `wisent-docs-search`,
`wisent-docs-search__label`, `wisent-docs-search__input`,
`wisent-docs-search__results`, `wisent-docs-search__hit`,
`wisent-docs-search__page`, `wisent-docs-search__text`,
`wisent-docs-search__empty`. The same seven sites each carried this as
`src/components/DocsSearch.jsx` with a private `docs-search.css`, and the
copies had already drifted apart: only skrzynka's indexed `blocks`, so on the
other six a page written as blocks was findable by its headings alone. That
version is the one kept here; the seven copies and their stylesheets are
retired.

## Figma component families

Version 0.8.1 covers every literal reusable component in **Wisent App**,
**Wisent Web**, and **Wisent Web App**: 340 components and 56 component sets.
There are two deliberate runtime paths:

- `WisentFigmaComponent` renders the checked-in literal Figma tree: source
  bounds, nesting, copy, paints, typography, effects, and the 16 image fills
  actually referenced by the reusable components;
- `WisentFigmaFamilyComponent` renders the same registry entry through a
  reusable semantic contract, for products replacing the design's literal
  copy and data.

This keeps fidelity and reuse separate. The old registry silently mapped every
literal component to one of 18 approximate families; it covered ids, not the
design. The literal renderer is now the default.

| Figma family | Runtime contract |
|---|---|
| `Wisent_logo`, named glyph components | `WisentBrandMark`, `WisentIcon` |
| `Button`, `CompactButton`, `ButtonDefault`, `ButtonHero`, `BadgeButton`, `BadgeButtonSmall` | `WisentAction` variants and sizes |
| `Badge App` | `WisentAppBadge` |
| `TopBar` | `WisentTopBar` |
| all `Sidebar navigation` variants | `WisentSidebarNavigation` |
| `SideMenuContainer`, `App` | `WisentSideMenu`, `WisentAppShell` |
| `Chat` | `WisentChat` |
| `Gercin card`, project collections | `WisentProjectCard`, `WisentProjectShowcase` |
| `Capabilities-Based Models/*`, including Representation Engineering and Hallucination Detection | `WisentCapabilityModel` |
| repeated auto-layout stacks, rows, grids, dividers, and surfaces | `WisentStack`, `WisentCluster`, `WisentGrid`, `WisentDivider`, `WisentSurface` |
| empty, modal, and status states | `WisentEmptyState`, `WisentModal`, `WisentStatusPanel` |
| `loader`, `SpinnerGap` | `WisentSkeleton` |

`figma-components.json` describes the public semantic families.
`figma-component-inventory.json` is the exact Figma inventory, while
`figma-component-registry.json` records every source-local node id, family, and
variant defaults. The generated `figmaSnapshots` payload holds the literal node
trees. The package build refuses a missing component or component set,
duplicate registry key, unresolved set membership, unknown implementation,
runtime export without a type declaration, type declaration without a runtime
export, or unknown Figma source.

The capability presentation is intentionally project-neutral:

```jsx
<WisentCapabilityModel
  title={project.title}
  description={project.summary}
  capabilities={project.capabilities}
  activeCapability={selectedCapability}
  stages={project.pipeline}
  tokens={project.tokens}
  metrics={project.metrics}
  controls={controls}
/>
```

Representation Engineering and Hallucination Detection therefore use the same
layout contract with different data. A new capability project does not require
a new component.

Render one literal component by stable source + node id:

```jsx
<WisentFigmaComponent
  source="Wisent Web"
  id="670:863"
  text={{ "Button label": "Start" }}
  overrides={{
    "670:865": { props: { onClick: start }, style: { pointerEvents: "auto" } },
  }}
/>
```

Overrides are keyed by Figma node id or node name. They can replace text,
children, style, DOM props, or one complete node. `assetBaseUrl` relocates the
bundled image fills; `imageResolver` gives an application complete control over
asset URLs. The stored Figma REST payload does not contain vector path geometry,
so a consumer that needs literal icon outlines supplies `vectorRenderer` or
replaces those named nodes. The package never invents a substitute glyph.

Use the project-neutral family instead when the layout is the contract:

```jsx
<WisentFigmaFamilyComponent
  source="Wisent Web"
  id="670:863"
  href="/start"
>
  Start
</WisentFigmaFamilyComponent>
```

`resolveFigmaComponent` returns the registry mapping,
`resolveFigmaComponentSet` returns its variants, and `resolveFigmaSnapshot`
returns the literal node tree. Figma node ids are file-local, so every resolver
uses `<source>:<id>` keys and rejects ambiguous id-only lookups.

## Icons come from the design, by name

Every application that lacked a glyph installed `lucide-react` — 117 imports
in echo-web, 107 in wisent-landing on 2026-09-01 — and a generic icon set is
the fastest way to make a screen read as generated. `WisentIcon` therefore
draws by name from a registry generated by `scripts/generate-icon-registry.mjs`
(`npm run icons`) out of two sources: the exact Figma SVG renders under
`figma/renders/` once the export has fetched them, and the reference
application's own icon modules (`wisent-app/src/components/Icons.js` and its
siblings, read and never written). Today the registry carries 48 glyphs from
the reference application — `home`, `assistants`, `community`, `updates`,
`plus`, `close`, `trash`, `edit`, `settings`, `bell`, `upload`, `check`,
`sparkle`, `voice`, `video`, … — and every entry names its origin.

```jsx
<WisentIcon name="home" size="small" />
<WisentIcon name="bell" label="Notifications" tone="muted" />
<WisentIcon source={<ProviderLogo />} label="GitHub" />   // a glyph the registry does not carry
```

A name the registry does not carry throws with the count of names it does;
an icon with neither `name` nor `source` throws, because the empty box is
what sent applications to a generic set in the first place. `wisentGlyphs`
exposes the registry and `resolveGlyph(name)` one entry.

The exact renders are fetched by `scripts/export-figma-source.sh` as a Stado
job on the Mac mini. It reads the existing Skarbiec Figma credential through
`FIGMA_TOKEN` (where the Stado agent has the declared scoped `--secret-env`),
the configured `FIGMA_TOKEN_COMMAND`, or `FIGMA_TOKEN_SOURCE=weles`. The
last option uses Weles's existing `weles-figma-design-assets-exporter` reader,
not a new grant to the Stado agent. `FIGMA_TOKEN_RENEW` is optional; renewing
a token does not reset Figma's per-user limit. No purchase is an export prerequisite.

The Weles reader comes from its installed admission release at
`~/.stado/services/weles-admission/current/darwin-arm/runtime`, not an old
partial token-acquisition checkout. The exporter resolves `current` once,
prints the resulting directory, and requires the endpoint helper, credential
reader, endpoint-resolution module, and scope catalog before contacting Figma.
`WELES_FIGMA_RUNTIME` can select another Weles release or a revision-pinned
reader bundle containing those four files at their repository paths. A missing
entry is reported as `Weles export reader is missing <path>`, not as a Figma
refusal. Reading this credential does not launch a browser or renew the token.

Git fetch and push disable credential helpers and terminal/askpass prompts;
SSH uses batch mode. If the configured deploy key cannot authenticate, the
export fails instead of opening a Keychain consent window or waiting for input.

The exporter acquires the token once and stops immediately if that reader
fails; it does not run a fetcher with empty stdin or print a misleading
`unchanged` export afterward. Weles's `invalid single-field response` diagnostic
names the Skarbiec endpoint, consumer, item and field, then reports returned
key names, identifier matches, and value/provider types and lengths without
printing the credential. This is a credential-response failure, not a Figma
HTTP refusal; a nonempty field in a host's vault does not prove that the
selected Skarbiec endpoint returned the expected response.
The optional provider is metadata, not a route name: the reader follows
Skarbiec's bound of 1–128 UTF-8 bytes with no NUL, CR or LF. Spaces,
punctuation and non-ASCII text do not invalidate an otherwise valid
credential response. A refused provider also reports its byte length and
`providerValid` without printing the metadata or credential.

The four source documents exported on 2026-08-12 remain in `figma/files/`.
The script adds exact vector paths and SVGs for the versions already recorded
in `figma/inventory.json`; it does not replace them with the latest design.
For the current 340 components, a fresh successful fetch needs **six Tier 1
requests**: one `GET file nodes` and one `GET image` for each of the three
component sources. `fetch-figma-file.mjs YjbhUB2uCYz1f75TQ3s8UE` adds the
reference application's fifth source with **one** document request, without
the former `depth=1` preflight. Image-fill URLs are Tier 2; downloading the
returned assets is not another Tier 1 request.

Geometry, render URLs, and partial file snapshots survive under
`figma/.export-cache/`. Geometry and SVGs are keyed by Figma file and version;
cached render URLs survive a stopped asset download. Only Figma's explicit
`null` image result means a node is unrenderable. HTTP 429 or 5xx never becomes
a `null` render and never causes recursive requests for smaller batches.

On HTTP 429, the command exits **75**, reports the failed endpoint and Figma's
full `Retry-After`, and saves the earliest retry time in
`figma/.export-cache/tier-1-<file-key>-retry.json` (tier 2 for image fills).
A rerun before that time sends no request for that file in that tier. A
different file can belong to another plan; its refusal is not inferred from
the first file's headers. Export it independently through the same host entry:

```sh
FIGMA_TOKEN_SOURCE=weles sh scripts/export-figma-source.sh --file YjbhUB2uCYz1f75TQ3s8UE
```

File-only mode publishes that snapshot or its recorded 404 without fetching
the component sources; it prints `audit-exit=not-run` and preserves failure.

Export one recorded component source independently with `--components`.
This does not request the fifth file or any other component source, so a
refusal for one file does not stop an accessible file's geometry and SVGs:

```sh
FIGMA_TOKEN_SOURCE=weles sh scripts/export-figma-source.sh --components fPvmXkvai4Aouum0hnAO6S
FIGMA_TOKEN_SOURCE=weles sh scripts/export-figma-source.sh --components iyYN8q8ZJMRy6oSKjjQIYo
```

The key must identify one of the three recorded component sources; an
unknown key is refused as `No recorded component source for Figma file <key>`
before a Figma request. Component-only mode publishes retained geometry and
render files with their manifest, preserves the fetch failure, and prints
`audit-exit=not-run`. The full command still regenerates the package and
audits all sources; a successful source-only export does not claim that every
component has its required evidence.

The timestamp is advice from Figma, not a promise of success or a monthly
reset. HTTP 403 reports the failed endpoint and Figma's response rather than
assuming an expired token or a missing file; HTTP 404 records the file in
`inventory.json.unreachable`
and exits nonzero. A partial export is neither a scheduled job nor success.
See Figma's [batching and version parameters](https://developers.figma.com/docs/rest-api/file-endpoints/)
and [rate-limit contract](https://developers.figma.com/docs/rest-api/rate-limits/).

`WISENT_COMPONENTS_REF` pins the source revision used on the host; the script
prints that revision, regenerates the snapshots and glyph registry, and
pushes a unique dated export branch without overwriting earlier branches.
It preserves the audit's exit status, including after publishing evidence.
`scripts/audit-figma-snapshot-support.mjs` counts components still without
vector evidence (312 of 340 in the recorded 2026-09-01 run). A build alone
does not prove visual parity; that remains the Probierz journey below.

Stado documents `--repo` as a clone without authentication. On a host where
that clone answers `Permission denied (publickey)`, deliver the committed
entrypoint with the documented
[`stado machine submit --request-file` source archive](https://stado.wisent.com/docs/machine-interface)
instead of changing the host's Git credentials. Package the script from the
chosen commit's `scripts` tree, not the commit archive: the latter adds a
`pax_global_header` that Stado's current archive reader refuses.

```sh
revision=$(git rev-parse HEAD)
mkdir -p .wisent-output
git archive --format=tar.gz --output=.wisent-output/figma-export-source.tar.gz "$revision:scripts" export-figma-source.sh
```

The saved machine request names that `source_archive_path`, the same `repo`
and `repo_ref`, `provider: "local"`, `pin_to_provider: true`, and the selected
host's consumer id in `pinned_host`. Its command runs
`env FIGMA_TOKEN_SOURCE=weles WISENT_COMPONENTS_REF=<same-revision> sh export-figma-source.sh --file <file-key>`.
Keep `client_request_id` with the request: replaying the identical request
returns the original job rather than duplicating an export. The archive and
request are job inputs, not a new product release or an export result.

## Data and forms

A product screen is a table, a filter rail, a form and a menu. Until 0.8.1 the
package shipped none of them, so every application drew its own and each one
drifted. These carry the names the SwiftUI side already uses in
`Sources/WisentDesignSystem/WisentAppShell.swift`, so a table means the same
thing in a native app and on the web, and they take their values from the
Figma node named beside each rule in `src/components.css`.

| Runtime contract | Figma family / SwiftUI type it implements |
|---|---|
| `WisentTableFrame` | `Table`, `Table header cell`, `Table cell` (Wisent Web App `535:34232`); compact rows are SwiftUI `WisentTableFrame` at `WisentAppLayout.tableRowHeight` |
| `WisentListRow` | the 36 px navigation row of `figma-navigation-exact-specs.txt`, and `_Select menu item` |
| `WisentSelect` | `Select` (Wisent Web App `415:23609`), on the platform's own `<select>` |
| `WisentTextarea` | the `Input` box of the same family, grown to several lines |
| `WisentSwitch` | `_Toggle base` (Wisent Web App `158:17318` on, `158:17326` off) |
| `WisentTabs` | `Tabs` and `Tab` (Wisent Web App `1612:45297`), and `_Code snippet tabs` |
| `WisentMenu` | `Menu items wrapper`, `Menu items`, `_Nav account card menu item` (Wisent Web App `651:37446`) |
| `WisentFacet`, `WisentFacetGroup`, `WisentFacetRail` | SwiftUI `WisentFacet`, `WisentFacetGroup`, `WisentFacetRail` at `WisentAppLayout.facetRailWidth` |
| `WisentCounterRow` | SwiftUI `WisentCounterRow` |
| `WisentKeyValue` | SwiftUI `WisentField`, the inspector's label-over-value unit |
| `WisentPagination` | `Pagination button group` (Wisent Web App `535:32614`) and `_Pagination number base` (Wisent Web `564:4092`) |

Three rules hold across all of them. A `<select>`, a `<textarea>` and a
checkbox stay native elements, because a listbox rebuilt in divs loses
type-ahead, the mobile wheel and the screen reader's mode. Waiting is the
skeleton of the content — `<WisentTableFrame busy>` draws
`WisentSkeletonTable` at its own column count, and nothing spins. Rows carry a
rule, never a stripe.

```jsx
<WisentTableFrame
  caption="Contrastive pairs"
  columns={[
    { key: "name", label: "Name" },
    { key: "model", label: "Model" },
    { key: "pairs", label: "Pairs", align: "end", width: "88px" },
  ]}
  rows={sets}
  rowKey={(set) => set.id}
  density="compact"
  selectedKeys={selected}
  onSelect={toggle}
  busy={loading}
  empty={<WisentEmptyState title="No pair set yet" description="Import one to start." />}
/>
```
## The Tailwind theme is the token set, and nothing else

An application that keeps Tailwind's default theme next to these tokens keeps
`bg-gray-500`, `from-indigo-500`, `rounded-3xl`, `shadow-2xl`, `animate-spin`
and `backdrop-blur` one keystroke away, and that is what every screen that
"looks generated" is made of. The build therefore emits the theme from
`tokens.json` in the shape each Tailwind version consumes, and the theme
**replaces** the default instead of extending it. Colors, fonts, radii,
shadows, animations, blurs and gradient images are the token set; spacing keeps
Tailwind's neutral scale.

Tailwind 3:

```js
// tailwind.config.js
module.exports = {
  presets: [require("@wisent-ai/components/tailwind-preset")],
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
};
```

Tailwind 4:

```css
@import "@wisent-ai/components/styles.css";
@import "tailwindcss";
@import "@wisent-ai/components/theme.css";
```

The utilities that exist afterwards are the token names: `bg-canvas`,
`bg-canvas-muted`, `bg-surface`, `text-ink`, `text-ink-strong`,
`text-secondary`, `text-muted`, `border-border`, `border-border-strong`,
`border-border-subtle`, `bg-brand`, `bg-brand-50` … `bg-brand-900`,
`bg-brand-hover`, `text-brand-link`, `text-success`, `text-warning`,
`text-danger`, `font-sans`, `font-expanded`, `font-mono`, `rounded-sm` (6 px)
… `rounded-2xl` (22 px), `shadow-surface`, `shadow-raised`. The sizes are
the library's scale under Tailwind's names, so the fleet's `text-sm` keeps
compiling and renders the design's step: `text-xs` 12/18, `text-sm` 14/20,
`text-base` 16/24, `text-lg` 18/28, `text-xl` 20/30, `text-2xl` 24/32,
`text-3xl` 30/38, `text-4xl` 36/44 -0.02em, `text-5xl` 48/60, `text-6xl`
60/72, `text-7xl` 72/90; the design's own names (`text-display-2xl` …
`text-text-xs`) are the same steps, `text-8xl` and `text-9xl` do not exist,
and the weights are `font-light` … `font-bold` (300 … 700). A token added
to `tokens.json` appears as a utility on the next build; a class that is
not a token does not compile.

## Dark appearance follows the OS, or the document, never a fork

Every dark rule is written once in the source as
`@media (prefers-color-scheme: dark)`, and the build derives the explicit
scopes from it: the media block applies unless the document says
`data-wisent-appearance="light"`, and every rule in it is repeated under
`[data-wisent-appearance="dark"]`. A product that is dark whatever the OS says
sets the attribute on `<html>` and gets `WisentPanel`, `WisentTableFrame`,
`WisentSelect`, `WisentTabs` and the rest as drawn for dark, from the
`--wisent-dark-*` tokens; a product that is light regardless sets `light`.

```html
<html data-wisent-appearance="dark">
```

## One revision for the whole web fleet

Web consumers vendor one tarball at
`vendor/wisent-components/<sha>/wisent-ai-components-<version>.tgz` and pin
the dependency to it, so a deployed interface names the exact commit it was
built from. `npm run pin -- --check` lists every sibling checkout that depends
on the package with its pinned commit and exits non-zero when any differs from
`HEAD` in what it packs: a pin at a commit whose packed paths (`package.json`
and the `files` it names) are byte-identical to `HEAD` reads `current-bytes`
and is not drift, because a commit that changed only the plan, a script or
this README packs the same tarball and re-pinning twenty-six repositories for
it would be churn. `npm run pin -- --apply` packs `HEAD`, writes the tarball
into each consumer, removes the previous one, rewrites the dependency and
refreshes the lockfile; `--apply --commit` then stages exactly those three
paths in each consumer, commits them as `Pin @wisent-ai/components at
<sha>: <subject>` and pushes `main`, so a fleet revision lands as twenty-odd
small commits from one command rather than twenty-odd hand-typed ones. A
consumer is held back — reported by `--check`, left untouched by `--apply` —
when its checkout is not on `main` or when its `package.json`, lockfile or
`vendor/wisent-components` already carries uncommitted changes: that is
another agent's work in flight, not this command's to sweep into a pin. Git
worktrees are skipped (their primary checkout is pinned), and so is
`wisent-app`, which is the reference the package is built from and is not
edited.

## The tells of a generated interface are a build failure

An agent that does not have the exact design value fills the gap with the
most common value in its training data. `wisent-design-lint` names each of
those substitutions and fails the build on it, with `path:line:col rule
message` per finding and a summary by rule:

```bash
npx wisent-design-lint            # the current repository
npx wisent-design-lint --json     # machine-readable
```

What counts as the design is measured, not decided by the lint. `tokens.json`
holds the Wisent Visual Identity variables under product names. The Figma exporter
(`weles/src/figma/parse-figma-document.py`, the one parse of a document the
export already makes) writes `figma/files/<folder>/vocabulary.json` per file:
every colour variable bound to a fill or stroke on a visible layer, resolved
to its value with its uses per page; every named style with the value of the
first node that uses it; the font families set on text, and every font size
a visible text layer carries with its count (`textSizes`) and the
family|size|line height|weight settings (`textSettings`); the corner radii
drawn; and per page the count of every gradient paint and blur or shadow
effect. Hidden layers are left out — the Untitled UI kit the pages were
started from leaves its purple variables on hidden variant layers inside
every instance — and fills drawn without a variable are counted apart, so a
palette colour and a one-off are told apart. `npm run vocabulary` merges
those four small files into `figma/vocabulary.json`; it reads no document.
A colour the designer defined as a variable or a fill style in any file is
the design, whichever file it sits in, and the largest corner drawn is the
top of the radius scale. Re-export a Figma file and run `npm run vocabulary`
in the same change; a per-file vocabulary whose version differs from the
export refuses to merge, and `npm run test:lint` refuses a merged vocabulary
whose file versions differ from `figma/inventory.json`. A file exported
before the parser wrote vocabularies is given one by running that parser
over its committed `document.json.gz` (`<document.json.gz> <summary.json>
<nodes.json> <vocabulary.json>`), which is how the four current ones were
made on 2026-09-14.

### Colour tokens are Figma variables

A colour token is a Figma variable under a product name, never a value an
agent chose. Until 2026-09-14 `tokens.json` carried Tailwind's `green-700`
as `success`, `amber-700` as `warning` and `red-700` as `danger`, a
`brandHover` and two dark surfaces that no Figma file holds, and a
`#273329` where the designer's Green 900 is `#273328`; the SwiftUI palette
was a second hand copy that had drifted from the first. Now:

- `node src/cli.mjs figma-variables` reads each exported file through the
  Figma MCP server (`https://mcp.figma.com/mcp`, the Plugin API behind
  `use_figma`) with the OAuth session Claude Code holds for it (`claude mcp
  add --scope user --transport http figma https://mcp.figma.com/mcp`, then
  `/mcp` → figma → Authenticate, as `lukasz.bartoszcze@wisent.ai`, the
  account with a Full seat) and writes `figma/files/<folder>/variables.json`:
  every variable bound in the file with its name, library key, collection,
  modes and values, the collections and modes, and the Wisent Visual
  Identity library's listing of names and keys. The REST Variables endpoint
  is Enterprise-only, which is why the names come this way.
- `--local` sends the same reads to the Figma desktop app's own MCP server
  (`http://127.0.0.1:3845/mcp`, no bearer), which serves the design file
  open in the app's active tab and answers "The MCP server is only
  available if your active tab is a design or FigJam file" otherwise; it is
  the route for a file whose team stops the remote reads, once that file is
  the active tab.
- `readThrough` in `figma/sources.json` selects an existing copy for
  measurement. A missing exported node id does not prove a missing design,
  an older copy, or a creation date. The earlier January dates were not
  established and have been removed. A fresh duplicate is made in Figma;
  neither this reader nor a successful old-id lookup duplicates a file.
- `--components --only <exported-key-or-folder>` measures the recorded
  component ids through the configured source. The persisted
  `components.json` reports `complete` and `unresolved` (exported id and
  name), while retaining every returned spec. Any unresolved id makes the
  command exit `1`; an incomplete read is never reported as full parity.
  This does not resolve changed component identities or prove visual equality.
  Run the real regression with
  `WISENT_FIGMA_COMPLETE_SOURCE=<source> WISENT_FIGMA_UNRESOLVED_SOURCE=<source> node --test tests/figma/components.test.mjs`.
  Both source selections must already be accessible through the existing
  Figma session. The command records the actual revision, status, output and
  persisted measurements under `.build/figma-components-evidence/`.
- `node src/cli.mjs figma-variables --library` reads the library itself.
  `figma/library.json` names the file the read takes the 88 local variables
  from: **Wisent Visual Identity (Copy)** (`ZZDm6PRWAFnzVnTuaAOGwC`), the
  duplicate of the library in "lukasz.bartoszcze's team", where the
  account's Full seat on Professional reads 200 calls a day. The original,
  Wisent Visual Identity (`3Lz7InbRSc7grrDJQg2O0d`), sits in the team
  "Wisent" (`1507798867862838476`), Starter and locked, where the same
  account has a View seat and 20 calls a month; `duplicateOf` records it.
  A duplicate gives every variable a new key while the files bind the
  published one, so a variable read from the duplicate keeps its published
  key from the listing the files carry, as `libraryKey`, and `vocabulary`
  joins on that. `--library --compare <fileKey>` says how another file's
  local variables differ from the record, by key and then by name, writing
  nothing: on 2026-09-14 the duplicate carried the original's 88 names and
  values exactly. A value or name that differs from the previous read is
  printed as `changed`. Without a source file the read falls back to
  importing every listed variable by key with `importVariableByKeyAsync`,
  which is a write and so needs a file the account can edit: the first such
  run created `https://www.figma.com/design/0zWUUqB54WqIedRnfGPvz4`
  ("wisent-components library read", in the account's drafts), recorded as
  `readFile`; it gives the published values, and agreed with the original.
- The duplicates of the consumer files (Wisent Web (Copy), Wisent Web App
  (Copy), Wisent App (Copy)) are no source for bound variables: `--probe`
  shows them reaching no library and a read through Wisent App (Copy)
  resolved none of its bound ids. Their bound variables are all library
  variables, which the library read covers, so nothing is lost.
- `figma/sources.json` names the live file behind an export whose key
  changed after the exporter took it: Wisent App is
  `39IKDRTM8FUBxZ1wI1xpou` today, exported as `fPvmXkvai4Aouum0hnAO6S`, a
  key Figma now answers with the sentence a nonexistent key gets ("Looks
  like you don't have edit access to this file"). The command reads through
  the live key and writes `exportedAs` beside it; the export on disk keeps
  the old key until the exporter runs with an account that sees the file.
- The probes: `--whoami` prints the plans and seats Figma attributes to the
  session; `--where <fileKey>,…` says per file whether the session reads it
  now or which team's allowance stops it; `--probe <fileKey>` says whether
  the session can read a file and which libraries it reaches; `--import
  <fileKey>,<key>,…` imports named variables through one file; `--call
  <tool> '<json>'` runs any tool and prints its answer; `--libraries`,
  `--search <fileKey>,<libraryKey>,<term>`, `--rest <path>` and `--tools`
  are the rest. The command stops with the server's sentence; files already
  written stay.
- Figma meters the reading tools by the plan of the team the file sits in
  and the reader's seat there ([rate limits & access](https://developers.figma.com/docs/figma-mcp-server/rate-limits-access/)):
  Starter, 20 calls a month; a Full seat on Professional, 200 a day. That is
  why the library is read from its duplicate, and why the originals of the
  consumer files (read once for their bound ids and listings) are only
  re-read when the team's month allows.
- `npm run vocabulary` joins the library with what the files hold: a library
  variable has the value the designer published, under her current name (a
  file's copy keeps the name it had when bound: `Grayscale/Gray 50` became
  `Shaded Gray/Gray 50`); a file's copy whose value differs from the
  library's is reported as a stale copy and kept as `inFiles`, so what the
  files render stays a colour the design defines. On 2026-09-14 three were
  stale: Gray 25 renders `#f8fdfb` in the files and is `#fafafa` in the
  library, Gray 50 `#ecf2f0` against `#eaece9`, Success Green 25 `#d1ffe6`
  against `#e9fff3`; the tokens follow the library. A variable the library
  lists but neither the library read nor an export values has no value.
- `figma/tokens.map.json` names the variable of every colour token, and
  `npm run tokens` writes `tokens.json` from it. A token whose variable
  neither the files nor the library name stops the command; a variable
  without a value stops it too, unless the map entry states a `value` and
  its `basis`, in which case the value is written and the token is listed in
  `tokens.json` `meta.unverified` and on stderr until a read gives the
  value — at which point the stated value is refused and the design's value
  wins. `npm run tokens -- --check` is what the build runs.
- `npm run build` writes the SwiftUI palette,
  `Sources/WisentDesignSystem/WisentDesignColors.swift`, from the same
  tokens as light/dark pairs (`WisentDesign.canvas` is `color.background`
  and `dark.canvas`), so the native and web consumers hold one palette.

`tests/tokens/` runs the command against this checkout and against fixture
roots: the committed tokens are the named variables' values, an unnamed
variable is refused, a valueless one needs a stated basis and is written as
unverified, and a stated value cannot override a read one.

Three rules that once lived here — no gradient, no backdrop blur, no gradient
text — were a theory of flat surfaces that no Figma file agrees with: on
visible layers Wisent Web alone paints 1,177 linear gradients and 1,130
background blurs, and Wisent Web App, the token source, paints 1,931 and 490.
On 2026-09-03 an agent held wisent.com to those rules and stripped the glass
top bar and the hero's gradients the designer had drawn. The rules are gone,
`tests/design-lint/` keeps them gone, and the lint below is what remains.

| Rule | What it catches | What replaces it |
|---|---|---|
| `raw-hex` | a hex colour that no Figma variable or fill style defines and no token names | a colour from `figma/vocabulary.json`, `var(--wisent-color-…)` or a preset utility |
| `tailwind-palette` | `bg-gray-500`, `from-indigo-500`, any default palette class | `bg-canvas`, `text-ink`, `border-border`, `bg-brand-…` |
| `spin-pulse` | `animate-spin`, `animate-pulse`, spinners | `WisentSkeleton`, `WisentBusyLabel` |
| `loading-copy` | rendered words that name the wait — `<p>Loading files…</p>`, `Text("Reading status…")` | the shape of what arrives (`WisentSkeletonTable`/`List`/`Text` at the destination's own row and column count), or `WisentProgressPanel` for an operation already in flight |
| `busy-rename` | a control that renames itself while its own action runs — `isRunning ? "Saving…" : "Save"`, `uploading ? t('files.uploading') : t('files.upload')` | the resting verb plus `isBusy` (`WisentAction`) or `WisentBusyLabel` |
| `radius-xl` | `rounded-3xl`/`4xl` or an arbitrary pixel radius larger than the largest corner in the design (`cornerRadiusMax` in `figma/vocabulary.json`) | a radius the design draws |
| `font-size` | `font-size: 13px`, `text-[9px]`: a size no Figma file sets on a visible text layer (`textSizes` in `figma/vocabulary.json`) | the scale: `text-xs` … `text-7xl`, or `var(--wisent-type-text-sm-size)` with its line height |
| `shadow-xl` | `shadow-xl`, `shadow-2xl` | `shadow-surface`, `shadow-raised` |
| `emoji` | an emoji in interface text | `WisentIcon` |
| `icon-library` | `lucide-react`, `react-icons`, `@heroicons`, `@radix-ui/react-icons`, … | `WisentIcon` with a glyph from the design |
| `google-font` | `next/font/google`, `fonts.googleapis.com` | the bundled Hubot Sans and IBM Plex Mono |
| `local-primitive` | a local `Button`, `Card`, `Badge`, `Skeleton`, `Toast`, `Dialog`, `Table`, `Select`, `Input`, … or a `components/ui/` directory | the package export the message names |
| `marketing-term` | "Seamless", "Unlock", "Elevate", "Supercharge", "Powered by AI", … in copy | a sentence that says what the product does |
| `unpinned-dependency` | a dependency on this package that is not a full commit | `npm run pin -- --apply` |

Files come from `git ls-files` under `src`, `app`, `components`, `pages`,
`styles`, `lib`, `Sources` and top-level stylesheets; `vendor`, `node_modules`,
`.next`, `dist` and `build` are never read. `.swift` is read because the two
copy rules apply to it: the panels that said "Loading status" instead of
drawing the table behind them were SwiftUI, and a lint that only read markup
could not see a single one of them. A repository may carry
`.wisent-design-lint.json`:

```json
{ "ignore": ["src/generated/**"], "allowHex": ["#f8fdfb"] }
```

`ignore` is for generated files; `allowHex` is for a generated token block
such as a landing page's `globals.css`. One occurrence that is the design
rather than a tell is admitted in place with its reason —
`// wisent-design-lint-allow icon-library: the provider's own logo set` on
the line or the line above — so the exception is visible where it applies.
The package lints its own `src/` on every build and passes, and
`npm run test:lint` drives the binary on fixture repositories: what the
designer drew passes with `ok: 2 files, 0 findings`, and a default palette
class, an undrawn colour and a radius past the design fail with the exact
sentences above.

The workspace-wide count that motivated this tool was taken by hand on
2026-09-01 (`DESIGN-PLAN.md`); this command replaces it, and the numbers are
not counted by hand again.

## Parity

The lint says a value is not a tell. Parity says the component looks like the
component. `tests/visual/figma-parity.spec.mjs` renders each of the 340
literal Figma components twice: the candidate is what this package draws from
the checked-in tree, the reference is the SVG Figma exported for the same
node, loaded on a page that carries none of this package's code. Both are
captured in one browser context at one device scale, clipped to the node's
`absoluteBoundingBox`, and compared pixel by pixel. The run keeps the
candidate, the reference and the measured percentage, and a difference mask
when a component fails.

`tests/visual/parity-thresholds.json` is the tolerance. `channelTolerance` is
how far one 8-bit channel may drift before a pixel counts as differing — it
absorbs text anti-aliasing, not colour. `defaultMaxDifferingPixelRatio` is
`0.02`: two per cent of a component's pixels may differ. `overrides` raises
that for one component key, and an entry that does not say why fails the
journey:

```json
{ "overrides": { "Wisent Web:1:2": { "maxDifferingPixelRatio": 0.05, "reason": "…" } } }
```

A component whose Figma export has not landed skips by name rather than
passing quietly, so the number of components actually compared is visible in
the run. Probierz owns execution: the journey is `figma-parity` of the
`wisent-components` app, and it runs on the Stado-selected host, never on a
laptop.

## Interfaces and compatibility

| Interface | Contract |
|---|---|
| `@wisent-ai/components` | React components and provider icons |
| `@wisent-ai/components/styles.css` | generated tokens, bundled fonts, and component styles |
| `@wisent-ai/components/theme.css` | Tailwind 4 `@theme` block: resets the default theme, defines the token set |
| `@wisent-ai/components/tailwind-preset` | Tailwind 3 preset: `theme` set (not extended) from the tokens |
| `@wisent-ai/components/skeleton` | React skeleton family and `WisentBusyLabel`, importable without the component library |
| `@wisent-ai/components/docs-search` | `WisentDocsSearch`, the one client component, kept out of the root export so a server page stays a server page |
| `@wisent-ai/components/skeleton.css` | the loading rules alone, themable through four `--wisent-skeleton-*` variables |
| `@wisent-ai/components/tokens` | JavaScript token object |
| `@wisent-ai/components/tokens.json` | framework-neutral token source |
| `@wisent-ai/components/landing-components` | React landing components used by generated pages, plus `landingForms`, `landingDefaultForms` and `landingFormOf` |
| `@wisent-ai/components/landing-components.json` | machine-readable landing component descriptions, forms, and per-form content contracts |
| `@wisent-ai/components/figma-components` | Figma-derived reusable semantic families |
| `@wisent-ai/components/figma-components.json` | machine-readable Figma-family-to-runtime mapping |
| `@wisent-ai/components/figma-registry` | inventory resolver plus literal and semantic renderers |
| `@wisent-ai/components/figma-snapshot` | literal snapshot resolver, renderer, asset map, and node trees |
| `@wisent-ai/components/figma-component-inventory.json` | exact 340-component and 56-set source inventory |
| `@wisent-ai/components/figma-component-registry.json` | exact per-node runtime mapping and variant defaults |
| `WisentDesignSystem` | SwiftUI colors, typography, surfaces, badges, metrics, headers, empty states, skeleton loading states, and buttons |

The package uses semantic HTML and has no dependency on Next.js, Tailwind, Radix, Supabase, or another authentication provider. React is a peer dependency so applications retain one React runtime.

The root export also re-exports the Figma snapshot trees (3.2 MB), so `package.json` declares `"sideEffects": ["*.css"]` and a bundler keeps only what a page imports. Measured with esbuild on an entry that imports `WisentTableFrame` from the root: 4,254 bytes with the declaration, 2,980,750 without it. Wisent Trade found the gap on 2026-09-03 as 82 kB to 312 kB of first-load JavaScript on one screen; no consumer needs a module rule to exclude the trees.

## Versioning, rollback, and support

`package.json` is the semantic version source. There is no npm or immutable release publication yet; the supported distribution is a private Git dependency pinned to a full commit SHA. Upgrade by changing that SHA, and roll back by restoring the prior SHA and lockfile entry.

Source and defects live in the private [`wisent-ai/wisent-components`](https://github.com/wisent-ai/wisent-components) repository. Security reports use a private [GitHub Security Advisory](https://github.com/wisent-ai/wisent-components/security/advisories/new). The package is internal and unlicensed for external distribution.
